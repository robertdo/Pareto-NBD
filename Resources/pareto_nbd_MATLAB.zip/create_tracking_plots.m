% create_tracking_plot.m
%
% Script to compute the repeat sales for the CDNOW dataset and create the
% associated tracking plots (both cumulative and incremental)
%
% Assumes -- the parameter estimates are contained in the vector params
%         -- the individual-level customer data are residing in memory
%         -- the spreadsheet cdnow_data.xls resides in the d:\ directory
%
% Peter S. Fader (http://petefader.com)
% Bruce G.S. Hardie (http://brucehardie.com)
% Ka Lok Lee (http://kaloklee.com)
%
% Last modified 2005-03-16

r = params(1); alpha = params(2);
s = params(3); beta  = params(4);

% determine cohort size by day of trial
ns = [];
for i = 1:84
    ns(i) = sum((T == (273-i)/7));
end

% generate sales cumulative forecast
endwk = 78;
endday = endwk*7; 

tmp1 = r*beta/(alpha*(s-1));
tmpcumsls1 = [];
for i = 1:endday
    tmp2 = (beta/(beta+i/7))^(s-1);
    tmpcumsls1(i) = tmp1*(1-tmp2);
end

tmpcumsls2 = zeros(84,endday);
for i = 1:84
    tmpcumsls2(i,:) = [ zeros(1,i) tmpcumsls1(1:endday-i) ];
end

cumrptsls = [];
dailysls = ns*tmpcumsls2;
for i = 1:endwk
    cumrptsls(i) = dailysls(i*7);
end    

% load actual cumulative repeat sales data
actual = xlsread('d:\cdnow_data','Cum. Repeat Sales','b1:b78');

% create tracking plot of cumulative repeat sales (pred. vs actual)
plot(1:endwk,actual,'k',1:endwk,cumrptsls,'k--', [39 39],[0 5000],'k--');
xlabel('Week'); ylabel('Cum. Rpt Transactions');
legend('Actual','Pareto/NBD',4);
print -depsc 'cumrptsls.eps'

% create tracking plot of weekly repeat sales (pred. vs actual)
incrptsls = [ cumrptsls(1) diff(cumrptsls) ];
incactual = [ actual(1) diff(actual)' ];
plot(1:endwk,incactual,'k',1:endwk,incrptsls,'k--', [39 39],[0 150],'k--');
xlabel('Week'); ylabel('Weekly Rpt Transactions');
legend('Actual','Pareto/NBD',4);
print -depsc 'incrptsls.eps'
