% load_data.m
%
% Script to load the CDNOW data from the spreadsheet cdnow_data.xls
%
% Assumes -- the spreadsheet cdnow_data.xls resides in the d:\ directory
%
% Peter S. Fader (http://petefader.com)
% Bruce G.S. Hardie (http://brucehardie.com)
% Ka Lok Lee (http://kaloklee.com)
%
% Last modified 2005-03-16

global p1x p2x tx T
tmpdata = xlsread('d:\cdnow_data','Individual-level Data','b2:e2358');
p1x = tmpdata(:,1);
tx = tmpdata(:,2);
T = tmpdata(:,3);
p2x = tmpdata(:,4);
clear tmpdata;
