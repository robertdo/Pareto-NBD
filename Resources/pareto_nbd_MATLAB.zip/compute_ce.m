% compute_ce.m
%
% Script to compute the Pareto/NBD conditional expectations
%
% Assumes -- the parameter estimates are contained in the vector params
%         -- the individual-level customer data are residing in memory
%         -- pactive (for each customer) resides in memory
%
% Peter S. Fader (http://petefader.com)
% Bruce G.S. Hardie (http://brucehardie.com)
% Ka Lok Lee (http://kaloklee.com)
%
% Last modified 2005-03-16

r = params(1); alpha = params(2);
s = params(3); beta  = params(4);

t = 39;  % period for which conditional expectations are to be computed
tmp1 = (r+p1x).*(beta+T)./((alpha+T).*(s-1));
tmp2 = ((beta+T)./(beta+T+t)).^(s-1);
ce = tmp1.*(1-tmp2).*pactive;

% compute average E[Y(t)|p1x,tx,T] and average actual number of 
% transactions in the second 39 weeks for each level of p1x
ce_act = zeros(max(p1x)+1,1);
ce_est = zeros(max(p1x)+1,1);
np1x = zeros(max(p1x)+1,1);
for y = unique(p1x)'
    isx = find(p1x==y);
    np1x(y+1) = length(isx);
    ce_act(y+1) = sum(p2x(isx))/np1x(y+1);
    ce_est(y+1) = sum(ce(isx))/np1x(y+1);
end
clear y isx

% create right-censored version for plot
censor = 7;  % right-censor at 7+
denom = sum(np1x(censor+1:length(np1x)));

ce_act_cen = ce_act(1:censor);
ce_act_cen(censor+1) = (np1x(censor+1:length(np1x))'...
    *ce_act(censor+1:length(np1x)))/denom;

ce_est_cen = ce_est(1:censor);
ce_est_cen(censor+1) = (np1x(censor+1:length(np1x))'...
    *ce_est(censor+1:length(np1x)))/denom;

plot([0:censor],ce_act_cen,'k',[0:censor],ce_est_cen,'kp--');
legend('Actual','Pareto/NBD',4);
xlabel('# Transactions in Weeks 1-39'); 
ylabel('Average # Transactions in Weeks 40-78');
axis([-.3 7.3 0 7]);
label = [ ' 0'; ' 1'; ' 2'; ' 3'; ' 4'; ' 5'; ' 6'; '7+' ];
set(gca,'xticklabel',label);
print -depsc 'ce_plot.eps'
