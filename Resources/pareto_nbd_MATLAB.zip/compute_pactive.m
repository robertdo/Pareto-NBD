% compute_pactive.m
%
% Script to compute P(active|p1x,tx,T) for Pareto/NBD model.
% Also creates a plot comparing average P(active|p1x,tx,T) with the
% observed proportion of customers active in the second period by p1x.
%
% Assumes -- the parameter estimates are contained in the vector params
%         -- the individual-level customer data are residing in memory
%
% Peter S. Fader (http://petefader.com)
% Bruce G.S. Hardie (http://brucehardie.com)
% Ka Lok Lee (http://kaloklee.com)
%
% Last modified 2005-03-16

% compute P(active|p1x,tx,T)
r = params(1); alpha = params(2);
s = params(3); beta  = params(4);

maxab = max(alpha,beta);
absab = abs(alpha-beta);
param2 = s+1;
if alpha < beta
    param2 = r+p1x;
end    

F0 = (alpha+T).^(r+p1x).*(beta+T).^s;
F1=h2f1(r+s+p1x,param2,r+s+p1x+1,absab./(maxab+tx))./...
    ((maxab+tx).^(r+s+p1x));
F2=h2f1(r+s+p1x,param2,r+s+p1x+1,absab./(maxab+T))./...
    ((maxab+T).^(r+s+p1x));
pactive = 1./(1+(s./(r+s+p1x)).*F0 .*(F1-F2));

% compute average P(active|p1x,tx,T) and determine the proportion of
% customers buying in the second 39 weeks for each level of p1x
pa_actual = zeros(max(p1x)+1,1);
pa_est = zeros(max(p1x)+1,1);
np1x = zeros(max(p1x)+1,1);
for y = unique(p1x)'
    isx = find(p1x==y);
    np1x(y+1) = length(isx);
    pa_actual(y+1) = sum(p2x(isx)>0)/np1x(y+1);
    pa_est(y+1) = sum(pactive(isx))/np1x(y+1);
end
clear y isx

% create right-censored version for plot
censor = 7;  % right-censor at 7+
denom = sum(np1x(censor+1:length(np1x)));

pa_act_cen = pa_actual(1:censor);
pa_act_cen(censor+1) = (np1x(censor+1:length(np1x))'*...
    pa_actual(censor+1:length(np1x)))/denom;

pa_est_cen = pa_est(1:censor);
pa_est_cen(censor+1) = (np1x(censor+1:length(np1x))'*...
    pa_est(censor+1:length(np1x)))/denom;

plot([0:censor],pa_act_cen,'k',[0:censor],pa_est_cen,'kp--');
legend('Empirical','Pareto/NBD',4);
xlabel('# Transactions in Weeks 1-39'); ylabel('P(active)');
axis([-.3 7.3 0 1]);
label = [ ' 0'; ' 1'; ' 2'; ' 3'; ' 4'; ' 5'; ' 6'; '7+' ];
set(gca,'xticklabel',label);
print -depsc 'pactive_grouped.eps'
