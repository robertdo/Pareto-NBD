% estimate_pareto_nbd.m
%
% Script to estimate the Pareto/NBD parameters
% *** requires the Optimization Toolbox ***
% *** assumes the script load_data.m has be run ***
%
% Peter S. Fader (http://petefader.com)
% Bruce G.S. Hardie (http://brucehardie.com)
% Ka Lok Lee (http://kaloklee.com)
%
% Last modified 2005-03-16

lb = .0001 * ones(1,4);
ub = 20 * ones(1,4);

initial = ones(1,4);

[params ll] = fmincon('pareto_nbd_ll',initial,[],[],[],[],lb,ub)